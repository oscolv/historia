Contenido
Shapefile del Estado de México según su extensión anterior a 1869, en proyección EPSG:6372 (Mexico ITRF2008 / LCC).

Cómo se construyó
Se obtuvo mediante la unión (dissolve) de los límites actuales de:

Estado de México

Hidalgo

Morelos

Calpulalpan (Tlaxcala)

De acuerdo con los decretos federales de 16 de enero y 17 de abril de 1869.

Área resultante
48,306.043 km² (calculada en EPSG:6372).

Crédito
Reconstrucción cartográfica, 2026.
